$(document).ready(()=>{

    function addImage(){
        var imageBlock = $('.image-block');
        var childImgTag = imageBlock.children();

        var img = $(' img ');
        var subImageBlock1 = $(' .sub-img1 ');
        var subImageBlock2 = $('.sub-img2 ');
        var subImageBlock3 = $(' .sub-img3 ');
        var subImageBlock4 = $(' .sub-img4');
        var subImageBlock5 = $('.sub-img5');
        var subImageBlock6 = $('.sub-img6');
        console.log(childImgTag);
        subImageBlock1.click(()=>{
            childImgTag.attr('src' , ' subImage1.jpg ');
        });
        subImageBlock2.click(()=>{
            childImgTag.attr('src' , ' subImage2.jpg ');
        });
        subImageBlock3.click(()=>{
            childImgTag.attr('src' , ' subImage3.jpg ');
        });
        subImageBlock4.click(()=>{
            childImgTag.attr('src' , ' subImage4.jpg ');
        });
        subImageBlock5.click(()=>{
            childImgTag.attr('src' , ' subImage5.jpg ');
        });
        subImageBlock6.click(()=>{
            childImgTag.attr('src' , ' mainImage.jpg ');
        });

    }
    addImage();
    var descShipingSpecsBlock = $(".desc-shiping-specs");
    var prodDetailsTab = $('.prodDetailsTab').click(()=>{
        descShipingSpecsBlock.html(` Green solid A-line kurta with block print detail, has a mandarin collar, long sleeves, flared hem, button closure.
        <br/>
        <b>Size & Fit</b><br/>
        The model (height 5'8") is wearing a size M <br/>
        <b> Material & Care </b><br/>
        Cotton
        Dry-clean`
        );
    });

    var specsTab = $('.specsTab').click(()=>{
        descShipingSpecsBlock.html(` 
        <b>Sleeve Length </b><br/> 
         Long Sleeves <br/> 
        <b>Shape </b><br/> 
         A-Line <br/> 
         <b>Neck </b><br/>
        Mandarin Collar <br/> 
        <b>Length </b><br/>
        Calf Length`
        );
    });

    var shipngDtlsTab = $('.shipngDtlsTab').click(()=>{
        descShipingSpecsBlock.html(` 
        Sold by:THE RAINBOW TRIBE  ( Supplied By Partner ) <br/>
        <b> Manufacturer/Packer/Importer Details </b> <br/>
            Manufacture Name- The Rainbow Tribe,<br/>
            Address- TA 108, Street no 2, Tuglakabad extn, New Delhi, 110019
            <b> Country of origin </b> <br/>
                india`
        );
    });




});

        
